package seleniumtest1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Sampleselenium 
{
	
	public static void  main(String[] args) 
	
	{
				
		 // Optional, if not specified, WebDriver will search your path for chromedriver.
		  System.setProperty("webdriver.chrome.driver", "C:/Users/Temp/chromedriver exe/chromedriver.exe");

		  // Create Cromedriver object
		 WebDriver driver = new ChromeDriver();
		 
		 // Launch the application
		 driver.get("http://room5.trivago.com");
		 
		//To maximize the window.		  
		 driver.manage().window().maximize();
		  
		 
		// This function is used to automate the destination search form testcase . This take driver object as input parameter
			Searchlocation(driver);
		 
		// This function is used to automate the Contact form testcase . This take driver object as input parameter
		ContactForm(driver);
		
				
}
	
	
	
	/* This function is written to automate the Contact form use case mention in Task_II 
	 * This take driver object as input parameter */
	
	public static void ContactForm(WebDriver driver)
	{
		
		// Get Contact link by xpath locator 
		WebElement ContactLink = driver.findElement(By.xpath("//footer[@id='footer']/div/div/div[2]/div/ul/li[2]"));
						
		Actions builder = new Actions(driver);
		
		// Move cursor to the contact Menu Element
		builder.moveToElement(ContactLink).perform();
		
		//wait to load the page
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
        builder.moveByOffset(0, 2576);
      
        // to maximize the window
        driver.manage().window().maximize();
        
        //to reach the end of the page				
         WebElement lastcor = driver.findElement(By.xpath("//footer[@id='footer']/div"));
         lastcor.click();
         
         
         // Get Contactlink element by xpath
         WebElement Contact = driver.findElement(By.xpath("//a[contains(text(),'Contact')]"));
       
         builder.moveToElement(Contact).build().perform();
     
         Contact.click();			
		
		// Get page title
		 String Pagetitle = driver.getTitle();
		 
		// Compair the web address
		if (0!= Pagetitle.compareTo("http://room5.trivago.com/contact/"))
			{
			
			WebElement Contacthading = driver.findElement(By.cssSelector("h2"));
			String text =    Contacthading.getText();
			
			if (0 != text.compareTo("Please give us feedback on what you want to read about"))
			{
				
				// Get messagebox address
				
				WebElement Messagebox = driver.findElement(By.id("message"));
				
				Messagebox.click();
				
				CharSequence[] message = {"welcome"};
				Messagebox.sendKeys(message);
				
				 JavascriptExecutor js = (JavascriptExecutor) driver;
				 // This  will scroll down the page by  1000 pixel vertical		
			        //js.executeScript("window.scrollBy(0,1000)",null;
						 
				 WebElement fullnamelabel = driver.findElement(By.xpath("div.col-6.col-12-sm > label"));
				 
				 
				 fullnamelabel.click();
				 js.executeScript("window.scrollBy(59,12)", null);		
				 
							
				//enter full name
				
				WebElement Fullname = driver.findElement(By.id("full_name"));
								
				builder.moveToElement(Fullname).build().perform();
				
				Fullname.click();
				
				CharSequence[] fullname = {"ABC"};
				Fullname.sendKeys(fullname);
				
				// Enter email
				WebElement Email = driver.findElement(By.id("email"));
				
				Email.click();
				
				CharSequence[] mailaddress = {"richa22shukla@gmail.com"};
				Fullname.sendKeys(mailaddress);
				
				//Click on submit
				
				WebElement Submitbutton = driver.findElement(By.id("contactform-submit"));
				
				Submitbutton.click();
				
				
				driver.quit();
				
				}
			else
			{
			
				System.out.println("error message");
				
				
			}
			
			System.out.println("error message");
			
		}
		
		else
		{
			
			System.out.println("error message");
		}
		
		
		
}

	/* This function is written to automate the search location use case mention in Task_II 
	 * This take driver object as input parameter */
	public static void Searchlocation(WebDriver driver)

	{
		// Search Bar icon element
		WebElement SearchIcon = driver.findElement(By.cssSelector("span.room5-icons-search"));
		
		// check if it present
	if (true == SearchIcon.isDisplayed())
	{
		// Click on
		SearchIcon.click();
		
		// get search element
		WebElement Searchdest = driver.findElement(By.id("ajax-search-input"));
		
		// click on web element 
		Searchdest.click();
		
		// Enter text
		CharSequence[] des = {"USA"};
		Searchdest.sendKeys(des);
		
		
		WebElement desResult = driver.findElement(By.cssSelector("div.post-thumbs-search"));
				
		
		System.out.println("desResult  = "+desResult);
		desResult.click();
		
			
	}
	else
	{
		System.out.println("error message");
	}
	
		driver.quit();
	}
	
	
}






	

